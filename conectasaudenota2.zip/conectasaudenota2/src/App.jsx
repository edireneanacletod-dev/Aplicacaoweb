import { 
  BrowserRouter, 
  Routes, Route 
} from 'react-router-dom';

import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';

import Home from './pages/Home.jsx';
import Sobre from './pages/Sobre.jsx';
import Recursos from './pages/Recursos.jsx';
import Contato from './pages/Contato.jsx';

export default 
function App() {
  return (
  <BrowserRouter>
    <Header />
    <main>
      <Routes>
        <Route path="/" 
        element={<Home />} 
        />
        <Route path="/sobre" 
        element={<Sobre />} 
        />
        <Route path="/recursos" 
        element={<Recursos />} 
        />
        <Route path="/contato" 
        element={<Contato />} 
        />
      </Routes>
    </main>
    <Footer />
  </BrowserRouter>
  );
}
