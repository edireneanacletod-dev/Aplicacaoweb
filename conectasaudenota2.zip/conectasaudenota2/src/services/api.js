const API_URL = 'https://api.adviceslip.com/advice';

export async function buscarConselho() {
  try {
    const resposta = await fetch(API_URL);

    if (!resposta.ok) {
      throw new Error('Não foi possível consultar a API.');
    }

    const dados = await resposta.json();

    if (!dados?.slip) {
      throw new Error('A API não retornou os dados esperados.');
    }

    return dados.slip;
  } catch (erro) {
    console.error('Erro ao consumir a API:', erro);
    throw erro;
  }
}
