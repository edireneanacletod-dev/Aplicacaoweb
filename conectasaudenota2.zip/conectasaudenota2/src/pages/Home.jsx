import { Link } from 'react-router-dom';

export default function Home() {
  const recursos = [
    ['Vacinação', 'Conteúdos educativos sobre prevenção e imunização.'],
    ['Saúde mental', 'Informações para estimular cuidado e bem-estar emocional.'],
    ['Prevenção', 'Conteúdos educativos para incentivar hábitos saudáveis.']
  ];

  return (
    <>
      <section className="hero py-5">
        <div className="container py-5 text-center">
          <span className="badge text-bg-success mb-3">ODS 3 — Saúde e Bem-Estar</span>
          <h1 className="display-4 fw-bold text-success">Conecta Saúde</h1>
          <p className="lead mx-auto hero-text">
            Informação, prevenção e tecnologia conectadas para promover saúde e bem-estar.
          </p>
          <Link className="btn btn-success btn-lg" to="/recursos">
            Conheça os recursos
          </Link>
        </div>
      </section>

      <section className="py-5">
        <div className="container">
          <div className="text-center mb-4">
            <h2 className="text-success">Informação que conecta você à saúde</h2>
            <p>Uma interface educativa, acessível e responsiva.</p>
          </div>

          <div className="row g-4">
            {recursos.map(([titulo, descricao]) => (
              <div className="col-md-4" key={titulo}>
                <div className="card h-100 border-0 shadow-sm">
                  <div className="card-body p-4">
                    <h3 className="h5 text-success">{titulo}</h3>
                    <p className="mb-0">{descricao}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
