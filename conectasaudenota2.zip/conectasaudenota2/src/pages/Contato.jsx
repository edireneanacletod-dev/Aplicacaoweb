import { useState } from 'react';

export default function Contato() {
  const [nome, setNome] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [enviado, setEnviado] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();

    const nomeDigitado = nome.trim();
    const mensagemDigitada = mensagem.trim();

    if (nomeDigitado === '') {
      alert('Digite seu nome.');
      setEnviado(false);
      return;
    }

    if (mensagemDigitada === '') {
      alert('Digite sua mensagem.');
      setEnviado(false);
      return;
    }

    setEnviado(true);
    setNome('');
    setMensagem('');
  }

  return (
    <section className="section">
      <div className="container">
        <span className="section-tag">Contato</span>
        <h1>Entre em contato</h1>
        <p>
          Envie sua mensagem para o Conecta Saúde. Sua participação é importante para nós.
        </p>

        <form className="form" onSubmit={handleSubmit}>
          <label htmlFor="nome">Nome</label>
          <input
            id="nome"
            name="nome"
            type="text"
            value={nome}
            onChange={(event) => {
              setNome(event.target.value);
              setEnviado(false);
            }}
            placeholder="Digite seu nome"
            required
          />

          <label htmlFor="mensagem">Mensagem</label>
          <textarea
            id="mensagem"
            name="mensagem"
            value={mensagem}
            onChange={(event) => {
              setMensagem(event.target.value);
              setEnviado(false);
            }}
            placeholder="Digite sua mensagem"
            rows="5"
            required
          />

          <button type="submit" className="btn-primary">
            Enviar mensagem
          </button>
        </form>

        {enviado && (
          <div className="success-message" role="alert">
            <strong>Mensagem registrada!</strong>
            <p>Obrigado pela participação.</p>
          </div>
        )}
      </div>
    </section>
  );
}
