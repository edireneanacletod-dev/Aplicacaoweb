export default 

function Sobre() {
  return (<section className="py-5">
    <div className="container content-page">
    <span className="badge text-bg-success mb-3">Sobre o projeto</span>
    <h1 className="text-success">Conecta Saúde e ODS 3</h1>
    <p>O Conecta Saúde é uma aplicação acadêmica criada para facilitar o acesso a informações educativas relacionadas à prevenção, vacinação, saúde mental e bem-estar.</p>
    <h2 className="h4 text-success mt-4">Situação-problema</h2>
    <p>A dificuldade de encontrar informações de saúde de forma organizada e acessível pode limitar o acesso da população a conteúdos educativos. A aplicação busca organizar esses conteúdos em uma interface simples.</p>
    <h2 className="h4 text-success mt-4">Público-alvo</h2>
    <p>Pessoas que desejam consultar informações educativas sobre saúde e prevenção.</p>
    <h2 className="h4 text-success mt-4">Objetivo</h2>
    <p>Desenvolver uma aplicação web responsiva que utilize tecnologias atuais de desenvolvimento para apresentar conteúdos educativos e dados externos.</p>
  </div></section>
  );
}
