import { useEffect, useState } from 'react';
import CardRecurso from '../components/CardRecurso.jsx';
import Loading from '../components/Loading.jsx';
import ErrorMessage from '../components/ErrorMessage.jsx';
import { buscarConselho } from '../services/api.js';

export default function Recursos() {
  const [conselho, setConselho] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  async function carregarConselho() {
    setCarregando(true);
    setErro('');

    try {
      const dados = await buscarConselho();
      setConselho(dados);
    } catch (error) {
      console.error(error);
      setErro('Não foi possível consultar os dados externos. Tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    document.title = 'Recursos | Conecta Saúde';
    carregarConselho();

    return () => {
      document.title = 'Conecta Saúde | Saúde e Bem-Estar';
    };
  }, []);

  return (
    <section className="py-5">
      <div className="container">
        <span className="badge text-bg-success mb-3">Recursos</span>
        <h1 className="text-success">Recursos do Conecta Saúde</h1>

        <div className="row g-4 mt-2">
          <div className="col-md-4">
            <CardRecurso
              titulo="Vacinação"
              descricao="Informações educativas sobre a importância da imunização e da prevenção."
            />
          </div>
          <div className="col-md-4">
            <CardRecurso
              titulo="Saúde mental"
              descricao="Conteúdos educativos relacionados ao cuidado e ao bem-estar emocional."
            />
          </div>
          <div className="col-md-4">
            <CardRecurso
              titulo="Prevenção"
              descricao="Informações para estimular atitudes preventivas e hábitos saudáveis."
            />
          </div>
        </div>

        <div className="api-box p-4 p-md-5 mt-5 rounded shadow-sm">
          <h2 className="h4 text-success">Consumo de dados externos</h2>
          <p>
            O exemplo abaixo demonstra uma requisição com Fetch API, conversão do retorno
            para JSON e atualização dinâmica da interface.
          </p>

          {carregando && <Loading />}
          {!carregando && erro && <ErrorMessage mensagem={erro} />}
          {!carregando && !erro && conselho && (
            <div className="conselho bg-white border-start border-success border-4 p-4 my-4">
              <p className="mb-0">{conselho.advice}</p>
            </div>
          )}

          <button
            className="btn btn-success"
            onClick={carregarConselho}
            disabled={carregando}
          >
            {carregando ? 'Carregando...' : 'Atualizar informação'}
          </button>
        </div>
      </div>
    </section>
  );
}
