import { NavLink } from 'react-router-dom';

export default function Header() {
  const linkClass = ({ isActive }) =>
    `nav-link ${isActive ? 'active fw-bold' : ''}`;

  return (
    <header className="sticky-top">
      <nav className="navbar navbar-expand-lg navbar-dark bg-success shadow-sm">
        <div className="container">
          <NavLink className="navbar-brand fw-bold" to="/">
            Conecta Saúde
          </NavLink>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#menuPrincipal"
            aria-controls="menuPrincipal"
            aria-expanded="false"
            aria-label="Abrir menu"
          >
            Menu
          </button>

          <div className="collapse navbar-collapse" id="menuPrincipal">
            <div className="navbar-nav ms-auto">
              <NavLink className={linkClass} to="/" end>
                Início
              </NavLink>
              <NavLink className={linkClass} to="/sobre">
                Sobre
              </NavLink>
              <NavLink className={linkClass} to="/recursos">
                Recursos
              </NavLink>
              <NavLink className={linkClass} to="/contato">
                Contato
              </NavLink>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
}
