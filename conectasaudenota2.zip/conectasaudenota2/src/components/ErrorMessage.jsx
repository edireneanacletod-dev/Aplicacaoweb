export default function ErrorMessage({ mensagem }) {
  return <div className="alert alert-warning" role="alert"><strong>Atenção:</strong> {mensagem}</div>
}
