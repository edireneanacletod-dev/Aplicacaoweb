export default function Loading() {
  return <div className="text-center py-3" role="status"><div className="spinner-border text-success" aria-hidden="true"></div><p className="mt-2 mb-0">Carregando informação...</p></div>
}
