export default 

function Footer() {
  return <footer className="bg-dark text-white text-center py-4 mt-5">
    <div className="container">
      <p className="mb-1">Conecta Saúde — ODS 3</p>
            </div>
  </footer>
}
