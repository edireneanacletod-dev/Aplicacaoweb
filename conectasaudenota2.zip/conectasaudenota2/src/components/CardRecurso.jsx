export default function CardRecurso({ titulo, descricao }) {
  return (
    <article className="card h-100 border-0 shadow-sm recurso-card">
      <div className="card-body p-4">
        <h3 className="h5 text-success">{titulo}</h3>
        <p className="mb-0">{descricao}</p>
      </div>
    </article>
  );
}
